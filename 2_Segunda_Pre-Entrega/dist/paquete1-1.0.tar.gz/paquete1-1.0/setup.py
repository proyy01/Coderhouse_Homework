from setuptools import setup

setup(
    name = "paquete1",
    version = "1.0",
    description = "Paquete de segunda pre-entrega",
    author = "Benjamin Rozas",
    author_email = "benjamin.rozas2001@gmail.com",

    packages = ["paquete1"]
)